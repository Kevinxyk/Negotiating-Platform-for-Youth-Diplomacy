// 示例：搜索框交互
document.querySelector('.hero input').addEventListener('focus', () => {
    console.log('搜索课程');
  });