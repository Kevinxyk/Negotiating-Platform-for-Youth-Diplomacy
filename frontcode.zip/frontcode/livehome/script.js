// 示例：加入直播按钮点击事件
document.querySelector('.hero button').addEventListener('click', () => {
    alert('加入辩论直播');
  });