// config.js
// 配置文件
export const currentConfig = {
  // API基础URL
  apiUrl: 'http://localhost:3000/api',
  // WebSocket URL
  wsUrl: 'ws://localhost:3000'
};