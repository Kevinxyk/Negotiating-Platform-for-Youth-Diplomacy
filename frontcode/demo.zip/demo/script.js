function copyRoomNumber() {
  const roomNumber = document.getElementById('roomNumber').textContent;
  navigator.clipboard.writeText(roomNumber).then(() => {
    alert('房间号已复制');
  });
}

document.getElementById('recordBtn').onclick = function() {
  this.classList.toggle('record-on');
};
function sendMsg() {
    const input = document.getElementById('chatInput');
    const chatBox = document.getElementById('chatBox');
    if (input.value.trim() !== '') {
      const p = document.createElement('p');
      p.classList.add('me');
      p.innerHTML = `<strong>我:</strong> ${input.value}`;
      chatBox.appendChild(p);
      input.value = '';
      chatBox.scrollTop = chatBox.scrollHeight;
    }
  }
  
  document.getElementById('micBtn').onclick = function() {
    this.textContent = this.textContent.includes('关闭') ? '🎤 麦克风' : '❌ 关闭麦克风';
  }
  
  document.getElementById('camBtn').onclick = function() {
    this.textContent = this.textContent.includes('关闭') ? '📹 摄像头' : '❌ 关闭摄像头';
  }
  
  // 倒计时相关逻辑
  let eventKey = "talking_phase";
  let timerInterval = null;
  
  async function fetchTimer() {
    try {
      const res = await fetch(`http://localhost:8000/api/time/${eventKey}`);
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      if (data) {
        updateTimerDisplay(data.remainingSec, data.label);
      }
    } catch (err) {
      console.error('Error fetching timer:', err);
    }
  }
  
  function formatTime(sec) {
    const minutes = Math.floor(sec / 60).toString().padStart(2, '0');
    const seconds = (sec % 60).toString().padStart(2, '0');
    return `${minutes}:${seconds}`;
  }
  
  function updateTimerDisplay(remainingSec, label) {
    const timer = document.getElementById('timer');
    timer.textContent = formatTime(remainingSec);
    document.getElementById('label').textContent = label;
  
    if (remainingSec <= 10) {
      timer.style.color = 'red';
    } else {
      timer.style.color = '#3478f6';
    }
  }
  
  function startTimer() {
    fetchTimer();
    timerInterval = setInterval(fetchTimer, 1000);
  }
  
  startTimer();